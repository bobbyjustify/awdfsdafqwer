use std::collections::{HashSet, VecDeque};
use std::sync::Mutex;

pub struct NeighborsData {
    pub public_ips: Mutex<HashSet<String>>,
    pub private_ips: Mutex<HashSet<String>>,
    pub processed_ips: Mutex<HashSet<String>>,
    pub queue: Mutex<VecDeque<String>>,
    pub online_ips: Mutex<HashSet<String>>,
    pub offline_ips: Mutex<HashSet<String>>,
    pub open_ports: Mutex<HashSet<String>>,
    pub closed_ports: Mutex<HashSet<String>>,
}

impl NeighborsData {
    pub fn new() -> Self {
        NeighborsData {
            public_ips: Mutex::new(HashSet::new()),
            private_ips: Mutex::new(HashSet::new()),
            processed_ips: Mutex::new(HashSet::new()),
            queue: Mutex::new(VecDeque::new()),
            online_ips: Mutex::new(HashSet::new()),
            offline_ips: Mutex::new(HashSet::new()),
            open_ports: Mutex::new(HashSet::new()),
            closed_ports: Mutex::new(HashSet::new()),
        }
    }
}

pub struct SeedIPs {
    pub ips: Vec<String>,
}

impl SeedIPs {
    pub fn new() -> Self {
        SeedIPs {
            ips: vec![
                "seed-0.mainnet.factz.co".to_string(),
                "seed-1.mainnet.factz.co".to_string(),
                "seed-2.mainnet.factz.co".to_string(),
            ],
        }
    }
}

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct RPCNeighbor {
    pub network_id: u32,
    pub peer_version: u32,
    #[serde(rename = "ip")]
    pub addrbytes: String,
    pub port: u16,
    pub public_key_hash: String,
    pub authenticated: bool,
}

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct RPCNeighborsResponse {
    pub bootstrap: Vec<RPCNeighbor>,
    pub sample: Vec<RPCNeighbor>,
    pub inbound: Vec<RPCNeighbor>,
    pub outbound: Vec<RPCNeighbor>,
}
