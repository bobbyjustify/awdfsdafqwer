use std::net::{IpAddr, SocketAddr, TcpStream};
use std::str::FromStr;
use std::time::Duration;

use mysql::*;
use mysql::prelude::Queryable;
use log::{info, warn, error};

const TIMEOUT_DURATION: Duration = Duration::from_secs(3);

pub fn check_and_update_ips(ips: &[String], pool: &Pool) -> Result<(), Box<dyn std::error::Error>> {
    let mut conn = pool.get_conn()?;

    for ip in ips {
        let is_online = match is_ip_online(ip) {
            Ok(online) => online,
            Err(e) => {
                warn!("Failed to check if IP {} is online: {}", ip, e);
                continue;
            }
        };

        let is_port_open = match is_port_open(ip, 20443) {
            Ok(open) => open,
            Err(e) => {
                warn!("Failed to check if port 20443 is open for IP {}: {}", ip, e);
                false
            }
        };

        match conn.exec_drop(
            r"UPDATE ips SET online = :online, port = :port WHERE ip = :ip",
            params! {
                "online" => is_online,
                "port" => if is_port_open { 20443 } else { 0 },
                "ip" => ip,
            },
        ) {
            Ok(_) => info!("Updated IP {} in the database", ip),
            Err(e) => error!("Failed to update IP {} in the database: {}", ip, e),
        }
    }

    Ok(())
}

pub fn is_ip_online(ip: &str) -> Result<bool, Box<dyn std::error::Error>> {
    match IpAddr::from_str(ip) {
        Ok(ip_addr) => match ip_addr {
            IpAddr::V4(ipv4) => Ok(!ipv4.is_private()),
            IpAddr::V6(ipv6) => Ok(!ipv6.is_loopback()),
        },
        Err(e) => Err(Box::new(e)),
    }
}

fn is_port_open(ip: &str, port: u16) -> Result<bool, Box<dyn std::error::Error>> {
    match SocketAddr::from_str(&format!("{}:{}", ip, port)) {
        Ok(socket_addr) => match TcpStream::connect_timeout(&socket_addr, TIMEOUT_DURATION) {
            Ok(_) => Ok(true),
            Err(e) => Err(Box::new(e)),
        },
        Err(e) => Err(Box::new(e)),
    }
}
