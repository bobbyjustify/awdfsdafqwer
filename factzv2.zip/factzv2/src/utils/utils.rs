use std::sync::Arc;
use mysql::*;
use mysql::prelude::Queryable;
use log::{info, warn, error};
use reqwest::blocking::Client;

use crate::models::models::NeighborsData;

pub fn setup_logger() {
    let log_file = std::fs::File::create("app.log").unwrap();
    let log_config = env_logger::Env::default().default_filter_or("info");
    env_logger::Builder::from_env(log_config)
        .target(env_logger::Target::Pipe(Box::new(log_file)))
        .init();
}

pub fn is_public_ip(ip: &str) -> bool {
    let octets: Vec<&str> = ip.split('.').collect();
    let first_octet = octets[0].parse::<u8>().unwrap_or(0);

    !(first_octet == 10
        || (first_octet == 172 && octets[1].parse::<u8>().unwrap_or(0) >= 16 && octets[1].parse::<u8>().unwrap_or(0) <= 31)
        || (first_octet == 192 && octets[1] == "168"))
}

pub fn connect_to_mysql() -> Result<Pool, Box<dyn std::error::Error>> {
    let url = "mysql://mysql:RojoRojo12Rojo@localhost:3306/targets";
    match Pool::new(url) {
        Ok(pool) => {
            match pool.get_conn() {
                Ok(mut conn) => {
                    match conn.exec_drop(
                        r"CREATE TABLE IF NOT EXISTS ips (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            ip VARCHAR(255) NOT NULL,
                            online BOOLEAN DEFAULT false,
                            port INTEGER DEFAULT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                        )",
                        (),
                    ) {
                        Ok(_) => {
                            info!("Connected to MySQL and created/verified 'ips' table");
                            Ok(pool)
                        }
                        Err(e) => {
                            error!("Failed to create/verify 'ips' table: {}", e);
                            Err(Box::new(e))
                        }
                    }
                }
                Err(e) => {
                    error!("Failed to get MySQL connection: {}", e);
                    Err(Box::new(e))
                }
            }
        }
        Err(e) => {
            error!("Failed to create MySQL connection pool: {}", e);
            Err(Box::new(e))
        }
    }
}

pub fn insert_to_mysql(conn: &Pool, ip: &str) -> Result<(), Box<dyn std::error::Error>> {
    match conn.get_conn() {
        Ok(mut conn) => {
            match conn.exec_first::<Option<u8>, _, _>(
                "SELECT 1 FROM ips WHERE ip = :ip",
                params! {
                    "ip" => ip,
                },
            ) {
                Ok(exists) => {
                    if exists.is_none() {
                        match conn.exec_drop::<_, _>(
                            "INSERT INTO ips (ip) VALUES (:ip)",
                            params! {
                                "ip" => ip,
                            },
                        ) {
                            Ok(_) => {
                                info!("Inserted IP {} into MySQL", ip);
                                Ok(())
                            }
                            Err(e) => {
                                error!("Failed to insert IP {} into MySQL: {}", ip, e);
                                Err(Box::new(e))
                            }
                        }
                    } else {
                        Ok(())
                    }
                }
                Err(e) => {
                    error!("Failed to check if IP {} exists in MySQL: {}", ip, e);
                    Err(Box::new(e))
                }
            }
        }
        Err(e) => {
            error!("Failed to get MySQL connection: {}", e);
            Err(Box::new(e))
        }
    }
}

pub fn get_neighbors(ip: &str, _client: &Client) -> Result<String, Box<dyn std::error::Error>> {
    let url = format!("http://{}:20443/v2/neighbors", ip);
    match reqwest::blocking::get(&url) {
        Ok(response) => match response.text() {
            Ok(body) => Ok(body),
            Err(e) => {
                error!("Failed to get response body from {}: {}", url, e);
                Err(Box::new(e))
            }
        },
        Err(e) => {
            warn!("Failed to get neighbors from {}: {}", url, e);
            Err(Box::new(e))
        }
    }
}

pub fn parse_and_insert_ips(neighbors: &str, neighbors_data: &Arc<NeighborsData>, conn: &Pool) -> Result<(), Box<dyn std::error::Error>> {
    let ip_regex = regex::Regex::new(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})").unwrap();

    for cap in ip_regex.captures_iter(neighbors) {
        let ip = cap[1].to_string();

        if is_public_ip(&ip) {
            neighbors_data.public_ips.lock().unwrap().insert(ip.clone());
            insert_to_mysql(conn, &ip)?;
        } else {
            neighbors_data.private_ips.lock().unwrap().insert(ip.clone());
        }
        neighbors_data.queue.lock().unwrap().push_back(ip);
    }

    Ok(())
}
