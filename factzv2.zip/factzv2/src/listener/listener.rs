use std::sync::Arc;
use std::thread;

use pcap::{Capture, Device};
use log::{info, error};
use mysql::Pool;
use etherparse::Ipv4HeaderSlice;

use crate::models::models::NeighborsData;
use crate::utils::utils::{is_public_ip, insert_to_mysql};

pub fn start_listener(neighbors_data: Arc<NeighborsData>, conn: Pool) {
    thread::spawn(move || {
        match Device::lookup() {
            Ok(device) => match device {
                Some(device) => {
                    match Capture::from_device(device).unwrap().promisc(true).snaplen(5000).open() {
                        Ok(mut cap) => {
                            match cap.filter("tcp port 20443 or tcp port 20444", true) {
                                Ok(_) => {
                                    while let Ok(packet) = cap.next_packet() {
                                        if let Some((src_ip, dst_ip)) = extract_ips(&packet) {
                                            if let Err(e) = process_ip(&src_ip, &neighbors_data, &conn) {
                                                error!("Failed to process source IP {}: {}", src_ip, e);
                                            }
                                            if let Err(e) = process_ip(&dst_ip, &neighbors_data, &conn) {
                                                error!("Failed to process destination IP {}: {}", dst_ip, e);
                                            }
                                        }
                                    }
                                }
                                Err(e) => error!("Failed to set filter: {}", e),
                            }
                        }
                        Err(e) => error!("Failed to open capture: {}", e),
                    }
                }
                None => error!("No network device found"),
            },
            Err(e) => error!("Error occurred while looking up network device: {}", e),
        }
    });
}

fn extract_ips(packet: &pcap::Packet) -> Option<(String, String)> {
    match Ipv4HeaderSlice::from_slice(&packet) {
        Ok(ip) => {
            let src_ip = ip.source_addr().to_string();
            let dst_ip = ip.destination_addr().to_string();
            Some((src_ip, dst_ip))
        }
        Err(e) => {
            error!("Failed to extract IPs from packet: {}", e);
            None
        }
    }
}

fn process_ip(ip: &str, neighbors_data: &Arc<NeighborsData>, conn: &Pool) -> Result<(), Box<dyn std::error::Error>> {
    if neighbors_data.processed_ips.lock().unwrap().contains(ip) {
        return Ok(());
    }

    if is_public_ip(ip) {
        neighbors_data.public_ips.lock().unwrap().insert(ip.to_string());
        insert_to_mysql(conn, ip)?;
    } else {
        neighbors_data.private_ips.lock().unwrap().insert(ip.to_string());
    }
    neighbors_data.processed_ips.lock().unwrap().insert(ip.to_string());
    info!("New IP detected: {}", ip);

    Ok(())
}
