// src/ui/ui.rs
use std::sync::Arc;
use std::time::Instant;

use prettytable::{Cell, Row, Table};
use colored::{ColoredString, Colorize};
use indicatif::{ProgressBar, ProgressStyle};
use log::{error, };

use crate::models::models::NeighborsData;


pub fn update_terminal_output(neighbors_data: &Arc<NeighborsData>, start_time: &Instant) {
    let progress_bar = create_progress_bar();

    let mut last_update_time = Instant::now();
    let update_interval = std::time::Duration::from_secs(1);

    loop {
        let neighbors_data = neighbors_data.clone();

        if last_update_time.elapsed() >= update_interval {
            clear_screen();

            println!("\n{} {}\n", "🚨".bright_red().bold(), "1337 H4X0R IP 5C4NN3R".bold().bright_green().underline());

            if let Err(e) = display_ip_table(&neighbors_data) {
                error!("Oops, the IP table is playing hard to get! 😞 {}", e);
            }

            display_stats(&neighbors_data, start_time);
            display_network_status(&neighbors_data);
            display_processing_speed(&neighbors_data, start_time);
            display_progress_bar(&neighbors_data);
            display_bro_quote();

            progress_bar.set_message(format!("H4ck1ng... ({} 1pz pwn3d)", neighbors_data.processed_ips.lock().unwrap().len()));
            progress_bar.tick();

            last_update_time = Instant::now();
        }

        std::thread::sleep(std::time::Duration::from_millis(100));
    }
}

/// 🎨 Clears the terminal screen, hacker-style! 🎨
fn clear_screen() {
    print!("{}[2J", 27 as char);
}

/// 🎛️ Creates a progress bar that looks like a hacker's dream! 🎛️
fn create_progress_bar() -> ProgressBar {
    let progress_bar = ProgressBar::new_spinner()
        .with_message("H4xing time...")
        .with_style(
            ProgressStyle::default_spinner()
                .tick_chars("⠁⠂⠄⡀⢀⠠⠐⠈")
                .template("{spinner:.bright_green} {msg}")
                .unwrap(),
        );
    progress_bar
}


fn display_ip_table(neighbors_data: &NeighborsData) -> Result<(), Box<dyn std::error::Error>> {
    let mut table = Table::new();
    table.set_titles(Row::new(vec![
        Cell::new("🌐 Public 1pz 🌐").with_style(prettytable::Attr::Bold).with_style(prettytable::Attr::ForegroundColor(prettytable::color::BRIGHT_GREEN)),
        Cell::new("🔒 Private 1pz 🔒").with_style(prettytable::Attr::Bold).with_style(prettytable::Attr::ForegroundColor(prettytable::color::BRIGHT_GREEN)),
        Cell::new("🍆  Queue 🍆 ").with_style(prettytable::Attr::Bold).with_style(prettytable::Attr::ForegroundColor(prettytable::color::BRIGHT_GREEN)),
    ]));

    let max_rows = 10;
    let num_rows = neighbors_data.public_ips.lock().unwrap().len().min(neighbors_data.private_ips.lock().unwrap().len()).min(neighbors_data.queue.lock().unwrap().len()).min(max_rows);

    for i in 0..num_rows {
        let public_ip = neighbors_data.public_ips.lock().unwrap().iter().nth(neighbors_data.public_ips.lock().unwrap().len() - i - 1).map(|s| s.to_string()).unwrap_or_else(String::new);
        let private_ip = neighbors_data.private_ips.lock().unwrap().iter().nth(neighbors_data.private_ips.lock().unwrap().len() - i - 1).map(|s| s.to_string()).unwrap_or_else(String::new);
        let queue_ip = neighbors_data.queue.lock().unwrap().get(i).map(|s| s.to_string()).unwrap_or_else(String::new);

        table.add_row(Row::new(vec![
            Cell::new(&public_ip).with_style(prettytable::Attr::ForegroundColor(prettytable::color::BRIGHT_CYAN)),
            Cell::new(&private_ip).with_style(prettytable::Attr::ForegroundColor(prettytable::color::BRIGHT_CYAN)),
            Cell::new(&queue_ip).with_style(prettytable::Attr::ForegroundColor(prettytable::color::BRIGHT_CYAN)),
        ]));
    }

    table.printstd();
    Ok(())
}

fn display_stats(neighbors_data: &NeighborsData, start_time: &Instant) {
    let total_ips = neighbors_data.public_ips.lock().unwrap().len() + neighbors_data.private_ips.lock().unwrap().len();
    let elapsed_time = start_time.elapsed();
    let duplicate_count = if neighbors_data.processed_ips.lock().unwrap().len() > total_ips {
        neighbors_data.processed_ips.lock().unwrap().len() - total_ips
    } else {
        0
    };

    println!("\n{} {}\n", "📊".bright_blue(), "H4ck1ng 5t4t5".bold().bright_blue().underline());
    println!("{} {}\n", "📈".bright_blue(), format!("T0t4l 1pz: {}", format_number(total_ips)));
    println!("{} {}\n", "🌐".bright_blue(), format!("Public 1pz: {}", format_number(neighbors_data.public_ips.lock().unwrap().len())));
    println!("{} {}\n", "🔒".bright_blue(), format!("Private 1pz: {}", format_number(neighbors_data.private_ips.lock().unwrap().len())));
    println!("{} {}\n", "🔍".bright_blue(), format!("Unique 1pz: {}", format_number(total_ips - duplicate_count)));
    println!("{} {}\n", "🚨".bright_red(), format!("Dupez: {}", format_number(duplicate_count)));
    println!("{} {}\n", "📚".bright_blue(), format!("Queu Size: {}", format_number(neighbors_data.queue.lock().unwrap().len())));
    println!("{} {}\n", "⏳".bright_blue(), format!("Elapsed : {}", format_duration(elapsed_time)));
}

/// 📡 Displays the network status like a hacker would! 📡
fn display_network_status(neighbors_data: &NeighborsData) {
    let online_count = neighbors_data.online_ips.lock().unwrap().len();
    let offline_count = neighbors_data.offline_ips.lock().unwrap().len();
    let open_ports_count = neighbors_data.open_ports.lock().unwrap().len();
    let closed_ports_count = neighbors_data.closed_ports.lock().unwrap().len();

    println!("\n{} {}\n", "📡".bright_blue(), "N3tw0rk 5t4tu5".bold().bright_blue().underline());
    println!("{} {}\n", "✅".bright_green(), format!(" ips: {}", format_number(online_count)));
    println!("{} {}\n", "❌".bright_red(), format!("0ffl1n3 ips: {}", format_number(offline_count)));
    println!("{} {}\n", "🔓".bright_green(), format!("0p3n P0rt5: {}", format_number(open_ports_count)));
    println!("{} {}\n", "🔒".bright_red(), format!("Cl053d P0rt5: {}", format_number(closed_ports_count)));
}

/// ⚡ Displays the hacking speed like a bolt of lightning! ⚡
fn display_processing_speed(neighbors_data: &NeighborsData, start_time: &Instant) {
    let total_ips = neighbors_data.public_ips.lock().unwrap().len() + neighbors_data.private_ips.lock().unwrap().len();
    let processing_speed = total_ips as f64 / start_time.elapsed().as_secs_f64();

    let speed_bar_width = 20;
    let filled_width = (processing_speed / 1000.0 * speed_bar_width as f64) as usize;
    let empty_width = speed_bar_width - filled_width;
    let speed_bar = format!(
        "[{}{}] {:.2} 1pz/5",
        "█".repeat(filled_width).bright_red(),
        " ".repeat(empty_width),
        processing_speed
    );

    println!("\n{} {}\n", "⚡".bright_yellow(), "👃LINES per minute ❄️".bold().bright_yellow().underline());
    println!("{}\n", speed_bar);
}

fn display_progress_bar(neighbors_data: &NeighborsData) {
    let processed_ips_count = neighbors_data.processed_ips.lock().unwrap().len();
    let remaining_ips_count = neighbors_data.queue.lock().unwrap().len();
    let total_ips_count = processed_ips_count + remaining_ips_count;
    let progress = processed_ips_count as f64 / total_ips_count as f64;
    let gauge_width = 50;
    let filled_width = (progress * gauge_width as f64) as usize;
    let empty_width = gauge_width - filled_width;
    let gauge = format!(
        "{}{}",
        "█".repeat(filled_width).bright_green(),
        "░".repeat(empty_width)
    );

    println!("\n{} {}\n", "📊".bright_blue(), "Progress nigga...💾 ".bold().bright_blue().underline());
    println!("{}\n", gauge);
}

/// 😎 Displays a bro quote that will make you feel like a hacking legend! 😎
fn display_bro_quote() {
    let bro_quotes = vec![
        "Bro, you're scanning IPs faster than a ninja! 🥷💻",
        "Dude, your IP hacking skills are off the charts! 📈🚀",
        "Bro, you're like the Kung Fu master of IP scanning! 🥋😎",
        "IP scanning is like a box of chocolates, you never know what you're gonna get! 🍫😄",
        "I'm not just scanning IPs, I'm hacking the mainframe! 🕵️‍♂️💻",
        "Dude, you're owning these IPs like a boss! 😎👑",
        "Bro, your IP scanning is so fast, it's breaking the space-time continuum! 🌌🚀",
    ];
    let random_index = rand::random::<usize>() % bro_quotes.len();
    let bro_quote = bro_quotes[random_index];

    println!("\n{} {}\n", "😎".bright_blue(), bro_quote.bold().bright_magenta());
}

fn format_number(number: usize) -> ColoredString {
    format!("{}", number).bright_magenta()
}


fn format_duration(duration: std::time::Duration) -> ColoredString {
    let secs = duration.as_secs();
    let millis = duration.subsec_millis();
    let hours = secs / 3600;
    let minutes = (secs % 3600) / 60;
    let seconds = secs % 60;

    if hours > 0 {
        format!("{:02}:{:02}:{:02}.{:03}", hours, minutes, seconds, millis).bright_magenta()
    } else if minutes > 0 {
        format!("{:02}:{:02}.{:03}", minutes, seconds, millis).bright_magenta()
    } else {
        format!("{:02}.{:03}5", seconds, millis).bright_magenta()
    }
}
