use std::sync::Arc;

use mysql::Pool;
use log::{warn, error};
use reqwest::blocking::Client;

use crate::models::models::NeighborsData;
use crate::utils::utils::{get_neighbors, parse_and_insert_ips};
use crate::checker::checker::is_ip_online;

pub fn process_neighbor(neighbors_data: &Arc<NeighborsData>, ip: &str, conn: &Pool, client: &Client) -> Result<(), Box<dyn std::error::Error>> {
    match is_ip_online(ip) {
        Ok(online) => {
            if !online {
                warn!("IP {} is not online, skipping", ip);
                return Ok(());
            }
        }
        Err(e) => {
            error!("Failed to check if IP {} is online: {}", ip, e);
            return Ok(());
        }
    }

    if neighbors_data.processed_ips.lock().unwrap().contains(ip) {
        return Ok(());
    }
    neighbors_data.processed_ips.lock().unwrap().insert(ip.to_string());

    match get_neighbors(ip, client) {
        Ok(neighbors_response) => {
            if let Err(e) = parse_and_insert_ips(&neighbors_response, neighbors_data, conn) {
                error!("Failed to parse and insert IPs for neighbor {}: {}", ip, e);
            }
        }
        Err(e) => {
            error!("Failed to get neighbors for IP {}: {}", ip, e);
        }
    }

    Ok(())
}
