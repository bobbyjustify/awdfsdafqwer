use std::sync::Arc;
use std::thread;
use std::time::Duration;
use std::time::Instant;
use reqwest::blocking::Client;
use log::{info, error};

mod neighbors;
mod utils;
mod models;
mod checker;
mod listener;
mod ui;

use neighbors::request::process_neighbor;
use utils::utils::{setup_logger, connect_to_mysql};
use models::models::{NeighborsData, SeedIPs};
use checker::checker::check_and_update_ips;
use listener::listener::start_listener;

const LOOP_INTERVAL: Duration = Duration::from_secs(5);

fn main() -> Result<(), Box<dyn std::error::Error>> {
    setup_logger();
    info!("Logger initialized");

    let neighbors_data = Arc::new(NeighborsData::new());
    let seed_ips = SeedIPs::new();

    for seed_ip in &seed_ips.ips {
        neighbors_data.queue.lock().unwrap().push_back(seed_ip.clone());
    }
    info!("Seed IPs added to the queue");

    let start_time = Instant::now();
    let output_neighbors_data = Arc::clone(&neighbors_data);
    let _output_thread = thread::spawn(move || {
        ui::ui::update_terminal_output(&output_neighbors_data, &start_time);
    });
    info!("UI output thread started");

    let pool = match connect_to_mysql() {
        Ok(pool) => {
            info!("Connected to MySQL database");
            pool
        }
        Err(e) => {
            error!("Failed to connect to MySQL: {}", e);
            return Err(e);
        }
    };

    let listener_neighbors_data = Arc::clone(&neighbors_data);
    start_listener(listener_neighbors_data, pool.clone());
    info!("Listener thread started");

    let client = Client::new();
    info!("HTTP client initialized");

    loop {
        let mut requests = Vec::new();

        while let Some(ip) = neighbors_data.queue.lock().unwrap().pop_front() {
            let neighbors_data = Arc::clone(&neighbors_data);
            let pool = pool.clone();
            let client = client.clone();
            let request = thread::spawn(move || {
                match process_neighbor(&neighbors_data, &ip, &pool, &client) {
                    Ok(_) => info!("Processed neighbor: {}", ip),
                    Err(e) => error!("Failed to process neighbor {}: {}", ip, e),
                }
            });
            requests.push(request);
        }

        for request in requests {
            if let Err(e) = request.join() {
                error!("Neighbor processing thread panicked: {:?}", e);
            }
        }
        info!("Processed all neighbors in the queue");

        let ips: Vec<String> = neighbors_data.processed_ips.lock().unwrap().iter().cloned().collect();
        match check_and_update_ips(&ips, &pool) {
            Ok(_) => info!("Checked and updated {} IPs", ips.len()),
            Err(e) => error!("Failed to check and update IPs: {}", e),
        }

        info!("Sleeping for {} seconds", LOOP_INTERVAL.as_secs());
        thread::sleep(LOOP_INTERVAL);
    }
}
